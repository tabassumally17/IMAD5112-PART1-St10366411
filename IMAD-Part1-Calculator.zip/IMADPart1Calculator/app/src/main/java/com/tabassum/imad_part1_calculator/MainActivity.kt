package com.tabassum.imad_part1_calculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView


class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //give ID's to the texts and buttons
        val button = findViewById<Button>(R.id.addbtn)
        val button2 = findViewById<Button>(R.id.subbtn)
        val numoneEditText= findViewById<EditText>(R.id.numoneEditText)
        val numtwoEditText= findViewById<EditText>(R.id.numtwoEditText)
        val Answer = findViewById<TextView>(R.id.display)
        val button3 = findViewById<Button>(R.id.mulbtn)
        val button4 = findViewById<Button>(R.id.divbtn)

        //set the sum for the addition button
        button.setOnClickListener {
            val num = numoneEditText.text.toString().toInt()
            val num2 = numtwoEditText.text.toString().toInt()
            val answer = num + num2
            Answer.text = "" + num +" +" + num2 + "=" + answer

        }

        //set the sum for the subtraction button
        button2.setOnClickListener {
            val num = numoneEditText.text.toString().toInt()
            val num2 = numtwoEditText.text.toString().toInt()
            val answer = num - num2
            Answer.text = "" + num +"-" + num2 + "=" + answer
        }

        //set the sum for the for the multiplication bhtton
        button3.setOnClickListener {
            val num = numoneEditText.text.toString().toInt()
            val num2 = numtwoEditText.text.toString().toInt()
            val answer = num * num2
            Answer.text = "" + num +"*" + num2 + "=" + answer
        }

        //set the sum for the division button
        button4.setOnClickListener {
            val num = numoneEditText.text.toString().toInt()
            val num2 = numtwoEditText.text.toString().toDouble()
            val answer = num / num2
            Answer.text = "" + num +"/" + num2 + "=" + answer
        }
    }

    }